<?php $__env->startSection('content'); ?>

<h4 class="lead text-center text-white bg-success p-2"><?php echo e($product->name); ?></h4>
<a href="/viewcart" class="btn btn-info mb-1">Back</a>
<?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container row mt-4">
        <div class="col-lg-4 col-md-4 mb-4">
            <img
            class="card-img-top"
src="/storage/images/<?php echo e($product->image); ?>"
            alt="product image"
     style=""/>
        </div>
        <div class="col-md-8 col-lg-8">
        <p><?php echo e($product->about); ?></p>
        <hr>
        <a class="mt-1 m-1 btn  btn-warning ">   <small class="text-dark">
            <?php if($product->rating == 4): ?>
            &#9733; &#9733; &#9733; &#9733;
            &#9734;
            <?php elseif($product->rating == 3): ?>
            &#9733; &#9733; &#9733; &#9734;
            &#9734;
            <?php elseif($product->rating == 2): ?>
            &#9733; &#9733; &#9734; &#9734;
            &#9734;
            <?php elseif($product->rating == 1): ?>
            &#9733; &#9734; &#9734; &#9734;
            &#9734;
            <?php else: ?>
            &#9733; &#9733; &#9733; &#9733;
            &#9733;
            <?php endif; ?>
          </small
          ></a>
        
<a href="/addtowishlist/<?php echo e($product->product_id); ?>" class=" text-white btn btn-primary mt-1 m-1"> Add to wishlist</a>
<?php if(auth()->user()->id == $product->user_id): ?>
<?php echo Form::open(['action' => ['CartController@destroy', $product->id], 'method'=>'DELETE']); ?>


<?php echo e(Form::submit('Remove from cart', ['class' => ['btn btn-danger', 'm-1']])); ?>

<?php echo Form::close(); ?>

<?php endif; ?>
</div>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shoplisting\resources\views/user/show.blade.php ENDPATH**/ ?>