<?php $__env->startSection('title', 'Products listing |  my  products'); ?>

<?php $__env->startSection('content'); ?>


<?php if(count($userproducts)> 0 ): ?>
        <?php $__currentLoopData = $userproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<div class="col-lg-4 col-md-6 mb-4">
    <div class="card h-100">

    <a href="/userproducts/<?php echo e($product->id); ?>"
            ><img
                class="card-img-top"
    src="/storage/images/<?php echo e($product->image); ?>"
                alt="product image"
         style=""/></a>
        <hr>
        
            <h4 class="card-title ml-2">
            <a href="/userproducts/<?php echo e($product->id); ?>"> <?php echo e($product->name); ?></a>
            </h4>
            <small class="ml-2"><b><?php echo e($product->prize); ?></b></small>

            <small class="ml-2 mb-1 text-dark">
              <?php if($product->rating == 4): ?>
              &#9733; &#9733; &#9733; &#9733;
              &#9734;
              <?php elseif($product->rating == 3): ?>
              &#9733; &#9733; &#9733; &#9734;
              &#9734;
              <?php elseif($product->rating == 2): ?>
              &#9733; &#9733; &#9734; &#9734;
              &#9734;
              <?php elseif($product->rating == 1): ?>
              &#9733; &#9734; &#9734; &#9734;
              &#9734;
              <?php else: ?>
              &#9733; &#9733; &#9733; &#9733;
              &#9733;
              <?php endif; ?>
            </small
            >
        </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($userproducts->links()); ?>

<?php else: ?>
<div class="container">
<h4 class="text-danger">You have no products!!!  <a href="/products/create" class="btn btn-warning">Add products?</a></h4>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shoplisting\resources\views/user/allproducts.blade.php ENDPATH**/ ?>