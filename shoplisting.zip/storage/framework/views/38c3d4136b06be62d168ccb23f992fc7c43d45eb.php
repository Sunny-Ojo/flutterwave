<?php $__env->startSection('title', 'Products listing | Contact Us'); ?>

<?php $__env->startSection('content'); ?>
<div class="  mt-4">
   <h1 class="lead  text-center">Products Listing | Contact Us</h1>
   <hr>
<div class="row">
    <div class="col-md-8 col-lg-8 offset-md-2">
        <?php echo Form::open(['action' => 'ContactController@store', 'method' => 'POST']); ?>

        <div class="form-group">
          <?php echo e(Form::label('name', 'Enter your name')); ?>

          <?php echo e(form::text('name', '', ['class' => 'form-control',  ])); ?>

      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <li class="text-danger"><?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
          <?php echo e(Form::label('email', 'Enter your email')); ?>

          <?php echo e(form::email('email', '', ['class' => 'form-control', ])); ?>

          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <li class="text-danger"><?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <div class="form-group">
          <?php echo e(Form::label('message', 'Enter your message')); ?>

          <?php echo e(form::textarea('message', '', ['class' => 'form-control', ])); ?>

          <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <li class="text-danger"><?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <div class="form-group">
          <?php echo e(Form::submit('Send Message',  ['class' => 'btn btn-primary' ])); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shoplisting\resources\views/contact.blade.php ENDPATH**/ ?>