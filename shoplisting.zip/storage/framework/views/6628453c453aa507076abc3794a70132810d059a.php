<?php $__env->startSection('title', 'Update a product'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-md-8 col-lg-8 offset-md-2">
            <div class="lead text-center bg-dark text-white-50 mb-3">
                Update Product
            </div>
  
            <?php echo Form::open(['action'=>['ProductsController@update',  $product->id], 'method'=> 'PUT', 'files'=>'true']); ?>

            <div class="form-group">
                <?php echo e(Form::label('name' , 'Enter name of product')); ?>

                <?php echo e(Form::text('name', $product->name, ['class'=>'form-control', 'placeholder'=>'name of product'])); ?>

          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <li class="text-danger"><?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <?php echo e(Form::label('prize' , 'Enter prize of product')); ?>

                <?php echo e(Form::text('prize', $product->prize, ['class'=>'form-control', 'placeholder'=>'prize of product'])); ?>

                <?php $__errorArgs = ['prize'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <li class="text-danger"><?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('category' , 'Enter category of product')); ?>

                <?php echo e(Form::text('category', $product->category, ['class'=>'form-control', 'placeholder'=>'category of product'])); ?>

                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <li class="text-danger"><?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::label('productInformation' , 'Enter Information about product')); ?>

                <?php echo e(Form::textarea('productInformation', $product->about, ['class'=>'form-control', 'placeholder'=>'Information of the product'])); ?>

                <?php $__errorArgs = ['productInformation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <li class="text-danger"><?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <?php echo e(Form::label('rating' , 'choose rating for the product')); ?>

                <?php echo e(Form::select('rating',['1' =>'1', '2'=>'2','3'=>'3','4'=>'4','5'=>'5'],  $product->rating, ['class'=>'form-control', 'placeholder'=>'product rating '])); ?>

                <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <li class="text-danger"><?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('image' , 'upload image of product')); ?> <br>
                <?php echo e(Form::file('image')); ?> <br>
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <li class="text-danger"><?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <img src="/storage/images/<?php echo e($product->image); ?>" alt="product image" style="width:35px:height:50;">
            </div>
            <div class="form-group">
                <?php echo e(Form::submit('Update product',['class'=> 'btn btn-outline-primary btn-block '])); ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shoplisting\resources\views/products/edit.blade.php ENDPATH**/ ?>