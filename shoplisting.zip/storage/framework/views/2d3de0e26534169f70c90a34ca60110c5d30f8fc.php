<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta
            name="viewport"
            content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />
        <meta name="description" content="" />
        <meta name="author" content="" />

        <title><?php echo $__env->yieldContent('title', 'Sunshinecoders products listing | Welcome'); ?></title>

        <!-- Bootstrap core CSS -->
        <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" />
          <!-- Custom styles for this template -->
        <link href="<?php echo e(asset('css1/shop-homepage.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('vendor1/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">

    </head>

    <body>

        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="/products"><?php echo e(config('app.name')); ?></a>
                <button
                    class="navbar-toggler"
                    type="button"
                    data-toggle="collapse"
                    data-target="#navbarResponsive"
                    aria-controls="navbarResponsive"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="/products"
                                >Home
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('about')); ?>">About</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('contact.create')); ?>">Contact</a>
                        </li>
                        <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">

                                <a class="dropdown-item" href="<?php echo e(route('products.create')); ?>">
                                   <i class="fa fa-edit"></i> <?php echo e(__('Create a new Product')); ?>

                                </a>

                                <a class="dropdown-item" href="<?php echo e(route('viewmyproducts')); ?>">
                                  <i class="fa fa-th-list"></i>  <?php echo e(__('My    Products')); ?>

                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('viewcart')); ?>">
                                <i class="fa fa-shopping-basket"></i>    <?php echo e(__('View    Cart')); ?>

                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('viewwishlist')); ?>">
                                  <i class="fa fa-heart"></i>  <?php echo e(__('My    wishist')); ?>

                                </a>
                               <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                <i class="fa fa-sign-out-alt"></i>    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>

                    </ul>
                </div>
            </div>
        </nav>

        <!-- Page Content -->
        <div class="container">
            <div class="row ">
                <div class="col-lg-3">
                    <h1 class="my-4">Items<span class="text-danger">S</span><span class="text-warning">how</span> &circledR;</h1>
                    <div class="list-group">
                        <h4 class="bg-success text-white p-1 text-center">Categories</h4>
                        <a href="/products " class="list-group-item">All products</a>

                        <?php if(count($cat)> 0): ?>
                            <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/categories/<?php echo e($item->name); ?> " class="list-group-item"><?php echo e($item->name); ?></a>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <p>No Categories yet</p>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- /.col-lg-3 -->

                <div class="col-lg-9 mt-3">
                    <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div
                        id="carouselExampleIndicators"
                        class="carousel slide my-4"
                        data-ride="carousel"
                    >
                        <ol class="carousel-indicators">
                            <li
                                data-target="#carouselExampleIndicators"
                                data-slide-to="0"
                                class="active"
                            ></li>
                            <li
                                data-target="#carouselExampleIndicators"
                                data-slide-to="1"
                            ></li>
                            <li
                                data-target="#carouselExampleIndicators"
                                data-slide-to="2"
                            ></li>
                        </ol>
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active">
                                <img
                                    class="d-block img-fluid"
                                    src="<?php echo e(asset('img/image1.jpg')); ?>"
                                    alt="First slide"
                                />
                            </div>
                            <div class="carousel-item">
                                <img
                                    class="d-block img-fluid"
                                    src="<?php echo e(asset('img/download.jpg')); ?>"
                                    alt="Second slide"
                                />
                            </div>
                            <div class="carousel-item">
                                <img
                                    class="d-block img-fluid"
                                    src="<?php echo e(asset('img/img2.jpg')); ?>"
                                    alt="Third slide"
                                />
                            </div>
                        </div>
                        <a
                            class="carousel-control-prev"
                            href="#carouselExampleIndicators"
                            role="button"
                            data-slide="prev"
                        >
                            <span
                                class="carousel-control-prev-icon"
                                aria-hidden="true"
                            ></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a
                            class="carousel-control-next"
                            href="#carouselExampleIndicators"
                            role="button"
                            data-slide="next"
                        >
                            <span
                                class="carousel-control-next-icon"
                                aria-hidden="true"
                            ></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                    <hr class="bg-warning">
        <div class="row">
                                <?php echo $__env->yieldContent('content'); ?>

        </div>

                    <!-- /.row -->
                </div>
                <!-- /.col-lg-9 -->
                </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->

        <!-- Footer -->
        <footer class="py-3 bg-dark">
            <div class="container">
                <p class="m-0 text-center text-white">
                    Copyright &copy; Sunshinecoder's Products listing, 2019 - <?php echo e(date('Y')); ?>

                </p>
            </div>
            <!-- /.container -->
        </footer>

        <!-- Bootstrap core JavaScript -->
        <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\wamp64\www\shoplisting\resources\views/layouts/products.blade.php ENDPATH**/ ?>